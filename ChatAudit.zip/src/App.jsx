
import React, { useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";

export default function AuditLetterGenerator() {
  const [departement, setDepartement] = useState("");
  const [procedure, setProcedure] = useState("");
  const [objectives, setObjectives] = useState("");

  const generateObjectives = () => {
    const prompt = `Quels sont les objectifs liés à l’audit du département ${departement} dans la procédure ${procedure} ?`;
    const fakeGPTResponse = `L’objectif de cette mission est d’évaluer les pratiques du département ${departement} concernant la procédure ${procedure}, d’identifier les points de non-conformité et de proposer des axes d’amélioration.`;
    setObjectives(fakeGPTResponse);
  };

  return (
    <div className="max-w-xl mx-auto p-4">
      <Card>
        <CardContent className="space-y-4 p-6">
          <h1 className="text-xl font-bold">ChatAudit – Générateur d'objectifs</h1>
          <Input
            placeholder="Département (ex: Direction Financière)"
            value={departement}
            onChange={(e) => setDepartement(e.target.value)}
          />
          <Input
            placeholder="Procédure (ex: gestion des achats)"
            value={procedure}
            onChange={(e) => setProcedure(e.target.value)}
          />
          <Button onClick={generateObjectives}>
            Générer les objectifs
          </Button>
          <Textarea
            className="min-h-[150px]"
            value={objectives}
            readOnly
            placeholder="Les objectifs générés apparaîtront ici..."
          />
        </CardContent>
      </Card>
    </div>
  );
}
