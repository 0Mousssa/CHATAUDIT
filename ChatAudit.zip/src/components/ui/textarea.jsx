
import React from "react";

export function Textarea({ value, onChange, placeholder, className = "", readOnly }) {
  return (
    <textarea
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      readOnly={readOnly}
      className={\`\${className} border border-gray-300 p-2 w-full rounded\`}
    />
  );
}
